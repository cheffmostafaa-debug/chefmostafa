import React, { useState } from 'react';
import { MenuItem } from '../types';
import { Plus, Utensils } from 'lucide-react';
import { useCart } from '../store/CartContext';

interface MenuItemCardProps {
  item: MenuItem;
}

export const MenuItemCard: React.FC<MenuItemCardProps> = ({ item }) => {
  const { addToCart } = useCart();
  const [imageError, setImageError] = useState(false);

  return (
    <div className="bg-white rounded-[20px] p-3 shadow-[0_2px_10px_-4px_rgba(0,0,0,0.05)] border border-gray-50 flex gap-4 items-center transform transition-all duration-200 hover:shadow-md active:scale-[0.99]">
      {/* Image */}
      <div className="relative w-[88px] h-[88px] flex-shrink-0 bg-gray-100 rounded-2xl overflow-hidden">
        {!imageError && item.image ? (
          <img 
            src={item.image} 
            alt={item.nameFr} 
            className="w-full h-full object-cover"
            loading="lazy"
            onError={() => setImageError(true)}
          />
        ) : (
          <div className="w-full h-full flex items-center justify-center text-gray-300">
            <Utensils size={32} />
          </div>
        )}
        {item.popular && (
          <div className="absolute -top-2 -left-2 bg-gradient-to-r from-orange-500 to-red-500 text-white text-[9px] font-bold px-2 py-1 rounded-lg shadow-sm uppercase tracking-wider flex items-center gap-1">
            <span className="w-1 h-1 bg-white rounded-full animate-pulse"></span>
            Top
          </div>
        )}
      </div>
      
      {/* Content */}
      <div className="flex-1 min-w-0 flex flex-col justify-center py-1">
        <div className="flex flex-col gap-0.5 mb-2">
          <div className="flex justify-between items-start w-full">
             <h3 className="font-bold text-gray-900 leading-tight truncate text-[15px]">{item.nameFr}</h3>
          </div>
          <span className="font-arabic text-sm text-gray-500 dir-rtl truncate text-right w-full">{item.nameAr}</span>
        </div>
        
        <div className="flex items-end justify-between mt-auto">
             <div className="flex flex-col">
                 <span className="text-primary font-bold text-lg leading-none">
                  {item.price} <span className="text-[10px] font-medium text-gray-400 uppercase">MRU</span>
                </span>
             </div>
            
            <button 
              onClick={(e) => {
                e.stopPropagation();
                addToCart(item);
              }}
              className="group bg-gray-100 text-gray-900 w-9 h-9 flex items-center justify-center rounded-full hover:bg-primary hover:text-white transition-all duration-200 shadow-sm active:scale-90"
              aria-label="Add to cart"
            >
              <Plus size={18} className="group-hover:rotate-90 transition-transform duration-200" />
            </button>
        </div>
      </div>
    </div>
  );
};